
export interface Book {
  book_id: number;
  title: string;
  author: string;
  price: number;
}
