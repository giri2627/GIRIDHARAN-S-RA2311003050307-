
import React from 'react';
import { Book } from '../types';
import BookItem from './BookItem';

interface BookListProps {
  books: Book[];
}

const BookList: React.FC<BookListProps> = ({ books }) => {
  if (books.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full bg-slate-800/50 p-10 rounded-xl border-2 border-dashed border-slate-700">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-slate-600 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v11.494m-5.747-8.994l11.494 5.996M17.747 6.253L6.253 12.247" />
           <path d="M3.272 12.008c0-3.37.585-6.61 1.66-9.664M20.728 12.008c0 3.37-.585 6.61-1.66 9.664" />
        </svg>
        <h2 className="text-xl font-semibold text-slate-400">No Books Yet</h2>
        <p className="text-slate-500 mt-1">Add a book using the form to see it here.</p>
      </div>
    );
  }
  
  return (
    <div className="space-y-4">
      {books.map((book) => (
        <BookItem key={book.book_id} book={book} />
      ))}
    </div>
  );
};

export default BookList;
