
import React, { useState } from 'react';
import { Book } from '../types';

interface BookFormProps {
  onAddBook: (book: Omit<Book, 'book_id'>) => void;
}

const BookForm: React.FC<BookFormProps> = ({ onAddBook }) => {
  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('');
  const [price, setPrice] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !author.trim() || !price) {
      setError('All fields are required.');
      return;
    }
    const priceValue = parseFloat(price);
    if (isNaN(priceValue) || priceValue <= 0) {
      setError('Please enter a valid positive price.');
      return;
    }
    
    onAddBook({ title, author, price: priceValue });
    setTitle('');
    setAuthor('');
    setPrice('');
    setError('');
  };

  return (
    <div className="bg-slate-800 p-6 rounded-xl shadow-2xl border border-slate-700">
      <h2 className="text-2xl font-bold mb-6 text-slate-100">Add New Book</h2>
      {error && <p className="bg-red-500/20 text-red-300 p-3 rounded-md mb-4 text-sm">{error}</p>}
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="title" className="block text-sm font-medium text-slate-400 mb-1">Title</label>
          <input
            id="title"
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="e.g., The Lord of the Rings"
            className="w-full bg-slate-900 border border-slate-700 rounded-md px-3 py-2 text-slate-200 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition duration-150"
          />
        </div>
        <div>
          <label htmlFor="author" className="block text-sm font-medium text-slate-400 mb-1">Author</label>
          <input
            id="author"
            type="text"
            value={author}
            onChange={(e) => setAuthor(e.target.value)}
            placeholder="e.g., J.R.R. Tolkien"
            className="w-full bg-slate-900 border border-slate-700 rounded-md px-3 py-2 text-slate-200 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition duration-150"
          />
        </div>
        <div>
          <label htmlFor="price" className="block text-sm font-medium text-slate-400 mb-1">Price</label>
          <div className="relative">
             <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
              <span className="text-slate-400 sm:text-sm">$</span>
            </div>
            <input
              id="price"
              type="number"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              placeholder="e.g., 25.00"
              step="0.01"
              min="0"
              className="w-full bg-slate-900 border border-slate-700 rounded-md pl-7 pr-3 py-2 text-slate-200 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition duration-150"
            />
          </div>
        </div>
        <button 
          type="submit"
          className="w-full bg-primary-600 hover:bg-primary-700 text-white font-bold py-2 px-4 rounded-md transition duration-300 ease-in-out transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-800 focus:ring-primary-500"
        >
          Add Book
        </button>
      </form>
    </div>
  );
};

export default BookForm;
