
import React from 'react';
import { Book } from '../types';

interface BookItemProps {
  book: Book;
}

const BookItem: React.FC<BookItemProps> = ({ book }) => {
  return (
    <div className="bg-slate-800 p-5 rounded-lg shadow-lg border border-slate-700 flex items-center justify-between hover:bg-slate-700/50 hover:border-primary-500 transition-all duration-300">
      <div>
        <h3 className="text-xl font-bold text-slate-100">{book.title}</h3>
        <p className="text-slate-400 italic">by {book.author}</p>
      </div>
      <div className="text-right">
        <p className="text-2xl font-mono font-semibold text-primary-400">
          ${book.price.toFixed(2)}
        </p>
      </div>
    </div>
  );
};

export default BookItem;
